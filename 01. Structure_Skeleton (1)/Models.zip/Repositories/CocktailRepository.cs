﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Repositories
{
    internal class CocktailRepository
    {
    }
}
