﻿namespace BoxData
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            double lenght=double.Parse(Console.ReadLine());
            double widht=double.Parse(Console.ReadLine());
            double height=double.Parse(Console.ReadLine());
            Box box = null;
            try
            {
               box = new Box(lenght, widht, height);
            }
            catch (ArgumentException ae)
            {

                Console.WriteLine(ae.Message);
                return;
            }
            Console.WriteLine(box);

        }
    }
}