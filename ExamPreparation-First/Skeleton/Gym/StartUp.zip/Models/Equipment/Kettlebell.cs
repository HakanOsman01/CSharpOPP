﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Equipment
{
    internal class Kettlebell
    {
    }
}
