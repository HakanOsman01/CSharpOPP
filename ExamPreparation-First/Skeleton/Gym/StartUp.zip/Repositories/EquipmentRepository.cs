﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Repositories
{
    internal class EquipmentRepository
    {
    }
}
