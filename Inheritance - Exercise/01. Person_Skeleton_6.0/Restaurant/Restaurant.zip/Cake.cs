﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Cake : Dessert
    {
        //•	Grams = 250
        //•	Calories = 1000
        //•	CakePrice = 5
        private const double DefaultGramsOfCake = 250;
        private const double DefaultCaloriesOfCake = 1000;
        private const decimal DefaultCakePrice = 5m;

        public Cake(string name, decimal price=DefaultCakePrice
            ,double grams=DefaultGramsOfCake, double calories=DefaultCaloriesOfCake) 
            : base(name, price, grams, calories)
        {
            
        }
    }
}
