﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Cake cake = new Cake("Cake",100,300,50);
            Console.WriteLine($"{cake.Name}-{cake.Grams} {cake.Calories} {cake.Price}");

        }
    }
}