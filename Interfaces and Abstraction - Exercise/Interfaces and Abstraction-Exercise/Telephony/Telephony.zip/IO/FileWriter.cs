﻿
using Telephony.IO.Interfaces;

namespace Telephony.IO
{
    public class FileWriter : IWriter
    {
        public void Write(string text)
        {
            
        }

        public void WriteLine(string text)
        {
           
        }
    }
}
