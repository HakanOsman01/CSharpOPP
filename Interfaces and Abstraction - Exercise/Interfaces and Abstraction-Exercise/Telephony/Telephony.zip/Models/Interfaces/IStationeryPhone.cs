﻿
namespace Telephony.Models.Interfaces
{
    public interface IStationeryPhone
    {
        string Call(string phoneNumber);
    }
}
