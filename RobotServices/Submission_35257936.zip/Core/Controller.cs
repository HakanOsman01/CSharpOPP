﻿using RobotService.Core.Contracts;
using RobotService.Models;
using RobotService.Models.Contracts;
using RobotService.Repositories;
using RobotService.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Core
{
    public class Controller : IController
    {
        private SupplementRepository supplements;
        private RobotRepository robots;
        public Controller()
        {
            supplements = new SupplementRepository();
            robots = new RobotRepository();
        }
        public string CreateRobot(string model, string typeName)
        {
            if(typeName!= "DomesticAssistant" &&  typeName!= "IndustrialAssistant")
            {
                return String.Format(OutputMessages.RobotCannotBeCreated, typeName);
            }
            IRobot robot = null;
            if(typeName== "DomesticAssistant")
            {
                robot = new DomesticAssistant(model);
            }
            else if(typeName== "IndustrialAssistant")
            {
                robot = new IndustrialAssistant(model);
            }
            this.robots.AddNew(robot);
            return String.Format(OutputMessages.RobotCreatedSuccessfully, typeName,model);
        }

        public string CreateSupplement(string typeName)
        {
           if(typeName!= "SpecializedArm" && typeName!= "LaserRadar")
           {
                return String.Format(OutputMessages.SupplementCannotBeCreated, typeName);
           }
           ISupplement supplement = null;
            if(typeName== "SpecializedArm")
            {
                supplement = new SpecializedArm();
            }
            else if(typeName== "LaserRadar")
            {
                supplement = new LaserRadar();
            }
            this.supplements.AddNew(supplement);
            return String.Format(OutputMessages.SupplementCreatedSuccessfully, typeName);
        }

        public string PerformService(string serviceName, int intefaceStandard, int totalPowerNeeded)
        {
            List<IRobot> servicesRobots = this.robots.Models()
                 .Where(r => r.InterfaceStandards.Contains(intefaceStandard))
                 .ToList();
            if (servicesRobots.Count == 0)
            {
                return String.Format(OutputMessages.UnableToPerform, intefaceStandard);
            }
            servicesRobots = servicesRobots
                .OrderByDescending(r => r.BatteryLevel)
                .ToList();
            int availablePower = servicesRobots.Sum(r => r.BatteryLevel);
            if (availablePower < totalPowerNeeded)
            {
                return String.Format(OutputMessages.MorePowerNeeded, serviceName, 
                    totalPowerNeeded - availablePower);
            }
            int usedRobotsCount= 0;
            bool isServiceExecute=false;
            while (totalPowerNeeded != 0)
            {
                foreach (IRobot robot in servicesRobots)
                {
                    if (robot.BatteryLevel >= totalPowerNeeded)
                    {
                        robot.ExecuteService(totalPowerNeeded);
                        usedRobotsCount++;
                        isServiceExecute = true;
                        break;
                    }
                    totalPowerNeeded -= robot.BatteryLevel;
                    robot.ExecuteService(robot.BatteryLevel);
                    usedRobotsCount++;
                    continue;
                }
                if(isServiceExecute)
                {
                    break;
                }
            }
            return String.Format(OutputMessages.PerformedSuccessfully, serviceName, usedRobotsCount);
        }

        public string Report()
        {
           List<IRobot>reportRobots=this.robots.Models()
           .OrderByDescending(r=>r.BatteryLevel)
           .ThenBy(r=>r.BatteryCapacity).ToList();
            StringBuilder sb=new StringBuilder();
            foreach (IRobot robot in reportRobots)
            {
                sb.AppendLine(robot.ToString());
            }
            return sb.ToString().Trim();
        }

        public string RobotRecovery(string model, int minutes)
        {
            List<IRobot>feedRobots=this.robots.Models()
           .Where(r=>r.Model==model && r.BatteryLevel
           <r.BatteryCapacity/2.00)
           .ToList();
            foreach (IRobot robot in feedRobots)
            {
                robot.Eating(minutes);
            }
            return String.Format(OutputMessages.RobotsFed,feedRobots.Count);
        }

        public string UpgradeRobot(string model, string supplementTypeName)
        {
            ISupplement supplement = this.supplements.Models()
                .FirstOrDefault(m => m.GetType().Name == supplementTypeName);
            int interfaceValue = supplement.InterfaceStandard;
            List<IRobot>notSupportingRobots=this.robots.Models()
            .Where(r=>!r.InterfaceStandards.Contains(interfaceValue))
            .Where(r=>r.Model==model).ToList();
            if (notSupportingRobots.Count == 0)
            {
                return String.Format(OutputMessages.AllModelsUpgraded, model);
            }
            IRobot robot = notSupportingRobots.First();
            robot.InstallSupplement(supplement);
            this.supplements.RemoveByName(supplement.GetType().Name);
            return String.Format(OutputMessages.UpgradeSuccessful, model,supplementTypeName);

        }
    }
}
