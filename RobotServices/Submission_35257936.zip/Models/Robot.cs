﻿using RobotService.Models.Contracts;
using RobotService.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Models
{
    public abstract class Robot : IRobot
    {
        private string model;
        private int batteryCapacity;
        public Robot(string model, int batteryCapacity, int conversionCapacityIndex)
        {
            Model=model;
            BatteryCapacity=batteryCapacity;
            BatteryLevel = batteryCapacity;
            ConvertionCapacityIndex= conversionCapacityIndex;
            this.interfaceStandards = new List<int>();
            
        }
        public string Model
        {
            get => model;
            private set
            {
                if(String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.ModelNullOrWhitespace);
                }
                model = value;
            }
        }

        public int BatteryCapacity
        {
            get=>batteryCapacity;
            private set
            {
                if(value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.BatteryCapacityBelowZero);
                }
                batteryCapacity = value;
            }
        }

        public int BatteryLevel { get;private set; }

        public int ConvertionCapacityIndex { get; private set; }

        private List<int> interfaceStandards;
        public IReadOnlyCollection<int> InterfaceStandards
        {
            get
            {
                return interfaceStandards.AsReadOnly();
            }
        }

        public void Eating(int minutes)
        {
            int produceEnergy = minutes * ConvertionCapacityIndex;
            if (BatteryCapacity <= BatteryLevel + produceEnergy)
            {
                BatteryLevel=BatteryCapacity;
            }
            else
            {
                BatteryLevel += produceEnergy;
            }
        }

        public bool ExecuteService(int consumedEnergy)
        {
            if (BatteryLevel >= consumedEnergy)
            {
                BatteryLevel -= consumedEnergy;
                return true;
            }
            return false;
        }

        public void InstallSupplement(ISupplement supplement)
        {
            int interfaceStandart = supplement.InterfaceStandard;
            interfaceStandards.Add(interfaceStandart);
            BatteryCapacity -= supplement.BatteryUsage;
            BatteryLevel -= supplement.BatteryUsage;
        }
        public override string ToString()
        {
            StringBuilder sb=new StringBuilder();
            List<int>standarts=this.interfaceStandards.ToList();
            sb.AppendLine($"{this.GetType().Name} {Model}:");
            sb.AppendLine($"--Maximum battery capacity: {BatteryCapacity}");
            sb.AppendLine($"--Current battery level: {BatteryLevel}");
            
            if(standarts.Count == 0)
            {
                sb.AppendLine("--Supplements installed: none");
            }
            else
            {
                sb.AppendLine($"--Supplements installed: {string.Join(" ",standarts)}");
            }
           return sb.ToString().Trim();
        }
    }
}
