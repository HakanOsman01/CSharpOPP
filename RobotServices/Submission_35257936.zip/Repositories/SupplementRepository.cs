﻿using RobotService.Models.Contracts;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Repositories
{
    public class SupplementRepository : IRepository<ISupplement>
    {
        private List<ISupplement> models;
        public SupplementRepository()
        {
            this.models=new List<ISupplement>();
            
        }
        public void AddNew(ISupplement model)
        {
            this.models.Add(model);
        }

        public ISupplement FindByStandard(int interfaceStandard)
        {
            return this.models.FirstOrDefault(m=>m.InterfaceStandard==interfaceStandard);
            
        }

        public IReadOnlyCollection<ISupplement> Models()
        {
           return models.AsReadOnly();  
        }

        public bool RemoveByName(string typeName)
        {

            ISupplement supplement = this.models.FirstOrDefault(m => m.GetType().Name == typeName);
            if (supplement == null)
            {
                return false;
            }
            this.models.Remove(supplement);
            return true;
        }
    }
}
